const mongoose = require ('mongoose');

mongoose.connect('mongodb://localhost/socketapp');

const UserSchema = new mongoose.Schema({
    userName: {
        type: String,
        trim: true,
        required: true
    },
    email: {
        type: String,
        unique: true,
        lowercase: true,
        trim: true,
        required: true
    },
    password: {
        type: String
    },
    created: {
        type: Date,
        default: Date.now
    }
});

UserSchema.methods.comparePassword = function(password) {
    return password === this.password;
  };

module.exports = mongoose.model('User', UserSchema);