
const User = require('../db/models/userModel');
const jwt = require('jsonwebtoken');

const signIn = function (req, res) {
    User.findOne({
        email: req.body.email
    }, function (err, user) {

        if (user == null || !user.comparePassword(req.body.password)) {
            return res.status(401).json({ message: 'მომხარებელი ვერ მოიძებნა' });
        }
        const token = jwt.sign({ email: user.email, userName: user.userName, _id: user._id }, process.env.JWT_SECRET)
        var newDate = new Date();
        var expDate = newDate.setMonth(newDate.getMonth() + 3)
        res.cookie('token', token, { sameSite: true, maxAge: expDate });
        return res.json({ token });
    });
};

const Authorize = function (req, res, next) {
    const token = req.cookies['token'];

    req.user = jwt.decode(token, process.env.JWT_SECRET);
    if (req.user === null) {
        return res.redirect('/');
    }

    User.findOne({ email: req.user.email }, function (err, user) {
        if (user === null) {
            return res.redirect('/');
        }
    });
    next()
}

const Register = function (req, res) {
    User.create({ email: req.body.email, password: req.body.password, userName: req.body.userName })
    res.redirect('/')
}

module.exports = { signIn, Authorize, Register };