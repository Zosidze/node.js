require('dotenv').config();

const express = require('express');
const app = express();

const http = require('http');
const server = http.createServer(app);
const { Server } = require('socket.io');
const io = new Server(server);
const { signIn, Authorize, Register } = require('./controllers');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
var Cookie = require('cookie');

app.use(cookieParser());
app.use(bodyParser.urlencoded());

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/templates/authorization/index.html');
});

app.post('/', signIn);

app.get('/chat', Authorize, (req, res) => {
    res.sendFile(__dirname + '/templates/chat.html');
});

app.get('/register', (req, res) => {
    res.sendFile(__dirname + '/templates/authorization/register.html')
})
app.post('/register', Register);

io.on('connection', (socket) => {

    socket.on('chat message', (text) => {
        const cookie = socket.handshake.headers['cookie'];
        const token = Cookie.parse(cookie)['token'];
        const user = jwt.decode(token, process.env.JWT_SECRET)
        io.emit('chat message', { userName: user.userName, txt: text });
    });

})
server.listen(3000, () => {
    console.log('listening on *:3000');
});